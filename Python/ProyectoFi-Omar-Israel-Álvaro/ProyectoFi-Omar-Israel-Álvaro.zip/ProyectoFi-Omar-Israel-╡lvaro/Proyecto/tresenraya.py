from tkinter import *
from tkinter import messagebox
import random
def menu_tres_en_raya():
    """Muestra el menu principal, con dos botones para seleccionar la modalidad de juego que queremos"""
    raiz=Tk()
    raiz.geometry("500x500")
    raiz.configure(bg="LightCyan2")
    boton_dos_jugadores=Button(raiz,text="Dos jugadores",height=3,width=12,bg="navy",fg="gold",font=("Helvatica",10,"bold"),command=lambda:partida_dos_jugadores())
    boton_un_jugador=Button(raiz,text="Un jugador",height=3,width=12,bg="navy",fg="gold",font=("Helvatica",10,"bold"),command=lambda:partida_un_jugador())
    boton_un_jugador.place(x=60,y=200)
    boton_dos_jugadores.place(x=320,y=200)
    etiqueta=Label(raiz,text="3 en raya, elige modo de juego",font=("Helvetica",20),bg="navy",fg="gold")
    etiqueta.pack(pady=20)
    def acabar_partida():
        """Función que cambia el estado de todos los botones a desactivado, indicando que se ha acabado la partida"""
        boton1.configure(state="disabled")
        boton2.configure(state="disabled")
        boton3.configure(state="disabled")
        boton4.configure(state="disabled")
        boton5.configure(state="disabled")
        boton6.configure(state="disabled")
        boton7.configure(state="disabled")
        boton8.configure(state="disabled")
        boton9.configure(state="disabled")

    def obtener_texto_boton(boton):
        """Función que devuelve el texto de un botón"""
        texto=boton["text"]
        return texto

    def cambiar_color_fondo(boton):
        """Función para cambiar el color de fondo del botón, en este caso será a verde ya que lo utilizaremos cuando un jugador gane"""
        boton.configure(bg="Green")

    def comprobar_ganador():
        """Función que comprueba si hay alguna combinación ganadora,si la hay lanzará un mensaje indicando el ganador, si no la hay y se ha llegado al número de movimientos máximo se lanzará un mensaje indicando que es empate"""
        #Primera Fila(X)
        if obtener_texto_boton(boton1)=="X" and obtener_texto_boton(boton2)=="X" and obtener_texto_boton(boton3)=="X":
            cambiar_color_fondo(boton1)
            cambiar_color_fondo(boton2)
            cambiar_color_fondo(boton3)
            fin_partida=True
            acabar_partida()
            messagebox.showinfo(title="Fin de la partida",message="El jugador X ha ganado")
        #Segunda Fila(X)
        elif obtener_texto_boton(boton4)=="X" and obtener_texto_boton(boton5)=="X" and obtener_texto_boton(boton6)=="X":
            cambiar_color_fondo(boton4)
            cambiar_color_fondo(boton5)
            cambiar_color_fondo(boton6)
            fin_partida=True
            acabar_partida()
            messagebox.showinfo(title="Fin de la partida",message="El jugador X ha ganado")
        #Tercera Fila(X)
        elif obtener_texto_boton(boton7)=="X" and obtener_texto_boton(boton8)=="X" and obtener_texto_boton(boton9)=="X":
            cambiar_color_fondo(boton7)
            cambiar_color_fondo(boton8)
            cambiar_color_fondo(boton9)
            fin_partida=True
            acabar_partida()
            messagebox.showinfo(title="Fin de la partida",message="El jugador X ha ganado")
        #Primera columna(X)
        elif obtener_texto_boton(boton1)=="X" and obtener_texto_boton(boton4)=="X" and obtener_texto_boton(boton7)=="X":
            cambiar_color_fondo(boton1)
            cambiar_color_fondo(boton4)
            cambiar_color_fondo(boton7)
            fin_partida=True
            acabar_partida()
            messagebox.showinfo(title="Fin de la partida",message="El jugador X ha ganado")
        #Segunda columna(X)
        elif obtener_texto_boton(boton2)=="X" and obtener_texto_boton(boton5)=="X" and obtener_texto_boton(boton8)=="X":
            cambiar_color_fondo(boton2)
            cambiar_color_fondo(boton5)
            cambiar_color_fondo(boton8)
            fin_partida=True
            acabar_partida()
            messagebox.showinfo(title="Fin de la partida",message="El jugador X ha ganado")
        #Tercera columna(X)
        elif obtener_texto_boton(boton3)=="X" and obtener_texto_boton(boton6)=="X" and obtener_texto_boton(boton9)=="X":
            cambiar_color_fondo(boton3)
            cambiar_color_fondo(boton6)
            cambiar_color_fondo(boton9)
            fin_partida=True
            acabar_partida()
            messagebox.showinfo(title="Fin de la partida",message="El jugador X ha ganado")
        #Diagonal principal(X)
        elif obtener_texto_boton(boton1)=="X" and obtener_texto_boton(boton5)=="X" and obtener_texto_boton(boton9)=="X":
            cambiar_color_fondo(boton1)
            cambiar_color_fondo(boton5)
            cambiar_color_fondo(boton9)
            fin_partida=True
            acabar_partida()
            messagebox.showinfo(title="Fin de la partida",message="El jugador X ha ganado")
        #Diagonal secundaria(X)
        elif obtener_texto_boton(boton3)=="X" and obtener_texto_boton(boton5)=="X" and obtener_texto_boton(boton7)=="X":
            cambiar_color_fondo(boton3)
            cambiar_color_fondo(boton5)
            cambiar_color_fondo(boton7)
            fin_partida=True
            acabar_partida()
            messagebox.showinfo(title="Fin de la partida",message="El jugador X ha ganado")
        #Primera fila(O)
        elif obtener_texto_boton(boton1)=="O" and obtener_texto_boton(boton2)=="O" and obtener_texto_boton(boton3)=="O":
            cambiar_color_fondo(boton1)
            cambiar_color_fondo(boton2)
            cambiar_color_fondo(boton3)
            fin_partida=True
            acabar_partida()
            messagebox.showinfo(title="Fin de la partida",message="El jugador O ha ganado")
        #Segunda fila(O)
        elif obtener_texto_boton(boton4)=="O" and obtener_texto_boton(boton5)=="O" and obtener_texto_boton(boton6)=="O":
            cambiar_color_fondo(boton4)
            cambiar_color_fondo(boton5)
            cambiar_color_fondo(boton6)
            fin_partida=True
            acabar_partida()
            messagebox.showinfo(title="Fin de la partida",message="El jugador O ha ganado")
        #Tercera fila(O)
        elif obtener_texto_boton(boton7)=="O" and obtener_texto_boton(boton8)=="O" and obtener_texto_boton(boton9)=="O":
            cambiar_color_fondo(boton7)
            cambiar_color_fondo(boton8)
            cambiar_color_fondo(boton9)
            fin_partida=True
            acabar_partida()
            messagebox.showinfo(title="Fin de la partida",message="El jugador O ha ganado")
        #Primera columna(O)
        elif obtener_texto_boton(boton1)=="O" and obtener_texto_boton(boton4)=="O" and obtener_texto_boton(boton7)=="O":
            cambiar_color_fondo(boton1)
            cambiar_color_fondo(boton4)
            cambiar_color_fondo(boton7)
            fin_partida=True
            acabar_partida()
            messagebox.showinfo(title="Fin de la partida",message="El jugador O ha ganado")
        #Segunda columna(O)
        elif obtener_texto_boton(boton2)=="O" and obtener_texto_boton(boton5)=="O" and obtener_texto_boton(boton8)=="O":
            cambiar_color_fondo(boton2)
            cambiar_color_fondo(boton5)
            cambiar_color_fondo(boton8)
            fin_partida=True
            acabar_partida()
            messagebox.showinfo(title="Fin de la partida",message="El jugador O ha ganado")
        #Tercera columna(O)
        elif obtener_texto_boton(boton3)=="O" and obtener_texto_boton(boton6)=="O" and obtener_texto_boton(boton9)=="O":
            cambiar_color_fondo(boton3)
            cambiar_color_fondo(boton6)
            cambiar_color_fondo(boton9)
            fin_partida=True
            acabar_partida()
            messagebox.showinfo(title="Fin de la partida",message="El jugador O ha ganado")
        #Diagonal principal(O)
        elif obtener_texto_boton(boton1)=="O" and obtener_texto_boton(boton5)=="O" and obtener_texto_boton(boton9)=="O":
            cambiar_color_fondo(boton1)
            cambiar_color_fondo(boton5)
            cambiar_color_fondo(boton9)
            fin_partida=True
            acabar_partida()
            messagebox.showinfo(title="Fin de la partida",message="El jugador O ha ganado")
        #Diagonal secundaria(O)
        elif obtener_texto_boton(boton3)=="O" and obtener_texto_boton(boton5)=="O" and obtener_texto_boton(boton7)=="O":
            cambiar_color_fondo(boton3)
            cambiar_color_fondo(boton5)
            cambiar_color_fondo(boton7)
            fin_partida=True
            acabar_partida()
            messagebox.showinfo(title="Fin de la partida",message="El jugador O ha ganado")
        #Empate
        elif cuenta==9:
            fin_partida=True
            messagebox.showinfo(title="Fin de la partida",message="Empate")

    def partida_un_jugador():
        """Funcion que tras ser llamada seleccionando un botón empieza una partida de un jugador, en la que se jugará contra el ordenador ejecutando movimientos aleatorios, también creamos un menú con el botón reiniciar partida"""
        pantalla2=Tk() #creamos la pantalla donde se mostrará la partida
        pantalla2.geometry("410x430") #indicamos si dimensión
        def empezar_un_jugador():
            """Inicializa la partida, creando los botones, añadiendolos a la pantalla en sus respectivas coordenadas y creamos una lista con los botones, en la que iremos eliminando aquellos que ya hayamos seleccionado
            para que la función random.choice seleccione uno correctamente"""
            global boton1,boton2,boton3,boton4,boton5,boton6,boton7,boton8,boton9
            global turnoX
            global cuenta
            global botones_disponibles
            global fin_partida
            botones_disponibles=[]
            turnoX=True
            cuenta=0
            fin_partida=False
            boton1=Button(pantalla2,text=" ",bg="LightCyan2",height=9,width=18,command=lambda:click_un_jugador(boton1))
            boton2=Button(pantalla2,text=" ",bg="LightCyan2",height=9,width=18,command=lambda:click_un_jugador(boton2))
            boton3=Button(pantalla2,text=" ",bg="LightCyan2",height=9,width=18,command=lambda:click_un_jugador(boton3))
            boton4=Button(pantalla2,text=" ",bg="LightCyan2",height=9,width=18,command=lambda:click_un_jugador(boton4))
            boton5=Button(pantalla2,text=" ",bg="LightCyan2",height=9,width=18,command=lambda:click_un_jugador(boton5))          #creamos los botones
            boton6=Button(pantalla2,text=" ",bg="LightCyan2",height=9,width=18,command=lambda:click_un_jugador(boton6))
            boton7=Button(pantalla2,text=" ",bg="LightCyan2",height=9,width=18,command=lambda:click_un_jugador(boton7))
            boton8=Button(pantalla2,text=" ",bg="LightCyan2",height=9,width=18,command=lambda:click_un_jugador(boton8))
            boton9=Button(pantalla2,text=" ",bg="LightCyan2",height=9,width=18,command=lambda:click_un_jugador(boton9))

            boton1.grid(row=0,column=0)
            boton2.grid(row=0,column=1)
            boton3.grid(row=0,column=2)

            boton4.grid(row=1,column=0)
            boton5.grid(row=1,column=1)                 #colocamos los botones en pantalla
            boton6.grid(row=1,column=2)

            boton7.grid(row=2,column=0)
            boton8.grid(row=2,column=1)
            boton9.grid(row=2,column=2)

            botones_disponibles.append(boton1)
            botones_disponibles.append(boton2)
            botones_disponibles.append(boton3)
            botones_disponibles.append(boton4)
            botones_disponibles.append(boton5)          #añadimos los botones a la lista
            botones_disponibles.append(boton6)
            botones_disponibles.append(boton7)
            botones_disponibles.append(boton8)
            botones_disponibles.append(boton9)
        empezar_un_jugador() # inicializamos los botones y los colocamos
        mi_menu=Menu(pantalla2) #creamos el menu
        pantalla2.configure(menu=mi_menu) #le añadimos a la pantalla el menu
        mi_menu.add_command(label="Reiniciar partida",command=empezar_un_jugador) #Le añadimos la etiqueta con la opción para reiniciar
        pantalla2.mainloop() #se muestra
        
    def partida_dos_jugadores():
        """Funcion que tras ser llamada seleccionando un botón empieza una partida de dos jugadores, también creamos un menú con el botón reiniciar partida"""
        pantalla=Tk()
        pantalla.geometry("410x430")
        def empezar():
            """Inicializa la partida, creando los botones, añadiendolos a la pantalla en sus respectivas coordenadas"""
            global boton1,boton2,boton3,boton4,boton5,boton6,boton7,boton8,boton9
            global turnoX
            global cuenta
            global fin_partida
            fin_partida=False
            turnoX=True
            cuenta=0
            boton1=Button(pantalla,text=" ",bg="LightCyan2",height=9,width=18,command=lambda:click(boton1))
            boton2=Button(pantalla,text=" ",bg="LightCyan2",height=9,width=18,command=lambda:click(boton2))
            boton3=Button(pantalla,text=" ",bg="LightCyan2",height=9,width=18,command=lambda:click(boton3))
            boton4=Button(pantalla,text=" ",bg="LightCyan2",height=9,width=18,command=lambda:click(boton4))
            boton5=Button(pantalla,text=" ",bg="LightCyan2",height=9,width=18,command=lambda:click(boton5))          #creamos los botones
            boton6=Button(pantalla,text=" ",bg="LightCyan2",height=9,width=18,command=lambda:click(boton6))
            boton7=Button(pantalla,text=" ",bg="LightCyan2",height=9,width=18,command=lambda:click(boton7))
            boton8=Button(pantalla,text=" ",bg="LightCyan2",height=9,width=18,command=lambda:click(boton8))
            boton9=Button(pantalla,text=" ",bg="LightCyan2",height=9,width=18,command=lambda:click(boton9))

            boton1.grid(row=0,column=0)
            boton2.grid(row=0,column=1)
            boton3.grid(row=0,column=2)

            boton4.grid(row=1,column=0)
            boton5.grid(row=1,column=1)                 #colocamos los botones
            boton6.grid(row=1,column=2)

            boton7.grid(row=2,column=0)
            boton8.grid(row=2,column=1)
            boton9.grid(row=2,column=2)
        empezar() # inicializamos los botones y los colocamos
        mi_menu=Menu(pantalla) #creamos el menu
        pantalla.configure(menu=mi_menu) #le añadimos a la pantalla el menu
        mi_menu.add_command(label="Reiniciar partida",command=empezar) #Le añadimos la etiqueta con la opción para reiniciar
        pantalla.mainloop() #se muestra

    def click(boton):
        """Función que utilizamos a la hora de seleccionar un botón, dependiendo del turno(si es el de X o el de O) pondrá el respectivo signo a no ser que se seleccione una casilla ya seleccionada que entonces enviará un mensaje de error"""
        global turnoX
        global cuenta
        if obtener_texto_boton(boton)==" " and turnoX==True:
            boton.configure(text="X")
            turnoX=False #Cambiamos el turno
            cuenta+=1    #Añadimos un valor a la cuenta por si hay un empate
            comprobar_ganador() 
        elif obtener_texto_boton(boton)==" " and turnoX==False:
            boton.configure(text="O")
            turnoX=True #Cambiamos el turno
            cuenta+=1   #Añadimos un valor a la cuenta por si hay un empate
            comprobar_ganador()
        else:
            messagebox.showerror(title="Error",message="Casilla ya seleccionada") #Muestra un mensaje de error si intentamos seleccionar una casilla que ya lo estaba

    def click_un_jugador(boton):
        """Función que tras hacer click en un boton hace click aleatoriamente en otro de los botones restantes, tras cada click, se comprueba si hay alguna combinación ganadora"""
        click(boton)
        botones_disponibles.remove(boton)   #eliminamos el boton de la lista de botones restantes
        if fin_partida:                     #si se acaba la partida paramos la ejecución de la función
            return
        else:
            boton_aleatorio=random.choice(botones_disponibles) # seleccionamos uno de los botones restantes de forma aleatoria
            click(boton_aleatorio)
            botones_disponibles.remove(boton_aleatorio) # tras hacer click lo eliminamos de la lista
    raiz.mainloop()

